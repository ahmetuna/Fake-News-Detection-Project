# Fake News Detection (Basic Scale)

This is a simple machine learning project demonstrating how to classify news as Fake or Real using a basic Logistic Regression model and TF-IDF vectorization.

## Project Structure
- `data/dataset.csv`: Contains a small synthetic dataset for training.
- `src/train.py`: Script to train the model and save the model artifacts.
- `src/predict.py`: Script to load the trained model and make predictions on new input.
- `models/`: Directory where the trained model and vectorizer will be saved (created automatically after training).
- `requirements.txt`: Python dependencies.

## Setup Instructions

1. **Install dependencies**:
   Make sure you have Python installed. If using a virtual environment, activate it first.
   ```bash
   pip install -r requirements.txt
   ```

2. **Train the model**:
   You need to train the model first to generate the model artifacts (saved in `models/` directory).
   ```bash
   python src/train.py
   ```

3. **Make Predictions**:
   You can make predictions either interactively or by passing text as a command-line argument.
   
   **Interactive Mode**:
   ```bash
   python src/predict.py
   ```
   
   **Command Line Argument**:
   ```bash
   python src/predict.py "Breaking: Scientists discover a new planet made of cheese!"
   ```
