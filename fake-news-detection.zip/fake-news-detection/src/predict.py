import joblib
import os
import sys

# Define paths
MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', 'models')
MODEL_PATH = os.path.join(MODEL_DIR, 'model.joblib')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'vectorizer.joblib')

def predict(text):
    if not os.path.exists(MODEL_PATH) or not os.path.exists(VECTORIZER_PATH):
        print("Error: Model files not found. Please run 'python src/train.py' first.")
        return
        
    # Load the saved model and vectorizer
    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    
    # Vectorize the input text
    text_vectorized = vectorizer.transform([text])
    
    # Make a prediction
    prediction = model.predict(text_vectorized)[0]
    probability = model.predict_proba(text_vectorized)[0]
    
    print(f"\nText: \"{text}\"")
    if prediction == 1:
        print(f"Prediction: FAKE NEWS (Probability: {probability[1]:.2f})")
    else:
        print(f"Prediction: REAL NEWS (Probability: {probability[0]:.2f})")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        # If user provides text as a command line argument
        input_text = " ".join(sys.argv[1:])
        predict(input_text)
    else:
        # Interactive mode
        print("Enter a news headline or text to check (or type 'quit' to exit):")
        while True:
            user_input = input("> ")
            if user_input.lower() in ['quit', 'exit', 'q']:
                break
            if user_input.strip() == "":
                continue
            predict(user_input)
