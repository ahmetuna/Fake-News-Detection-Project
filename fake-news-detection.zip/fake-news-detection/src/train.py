import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib
import os

# Define paths
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'dataset.csv')
MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', 'models')
MODEL_PATH = os.path.join(MODEL_DIR, 'model.joblib')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'vectorizer.joblib')

def train():
    print("Loading dataset...")
    df = pd.read_csv(DATA_PATH)
    
    X = df['text']
    y = df['label']

    print("Vectorizing text data...")
    vectorizer = TfidfVectorizer(stop_words='english')
    X_vectorized = vectorizer.fit_transform(X)

    print("Training Logistic Regression model...")
    model = LogisticRegression()
    model.fit(X_vectorized, y)

    print("Saving model and vectorizer...")
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

    print(f"Training complete! Model saved to {MODEL_DIR}")

if __name__ == "__main__":
    train()
